import React, { Component } from "react";
import { View, Text, Image, Button } from "react-native";
import Ionicons from "react-native-vector-icons/Ionicons";
export default class PhotoSection extends Component {
  styles = {
    container: {
      margin: 10,
      flex: 1,
      borderWidth: 0.5,
      borderRadius: 5,
      padding: 2,
      maxWidth: 600
    },
    thumbnail: { flex: 1, flexDirection: "row", padding: 10 },
    usernameContainer: {
      justifyContent: "center",

      padding: 10
    },
    hearticon: {
      paddingTop: 10,
      paddingBottom: 10
    },
    containerbottom: {
      flex: 1,
      flexDirection: "row"
    }
  };
  render() {
    return (
      <View style={this.styles.container}>
        <View style={this.styles.thumbnail}>
          <Image
            style={{
              width: 50,
              height: 50,
              backgroundColor: "black",
              borderRadius: 25
            }}
            source={{
              uri: "./assests/avatar.png"
            }}
          />
          <View style={this.styles.usernameContainer}>
            <Text
              style={{
                fontWeight: "bold"
              }}
            >
              UserName
            </Text>
          </View>
        </View>
        <View>
          <Image
            style={{ width: null, height: 400, backgroundColor: "blue" }}
            source={{
              uri: "./assests/helping.jpg"
            }}
          />
        </View>
        <View>
          <Ionicons
            style={this.styles.hearticon}
            name="md-heart-empty"
            size={30}
          />
        </View>
        <View style={this.styles.containerbottom}>
          <Text
            style={{
              paddingRight: 10,
              fontWeight: "bold"
            }}
          >
            UserName
          </Text>
          <Text>Caption</Text>
        </View>
      </View>
    );
  }
}

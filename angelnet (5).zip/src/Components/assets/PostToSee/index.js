import React, { Component } from "react";
import Post from "./Post";
export default class PhotoSection extends Component {
  render() {
    return <Post />;
  }
}

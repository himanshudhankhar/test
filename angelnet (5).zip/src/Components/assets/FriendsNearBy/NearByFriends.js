import React, { Component } from "react";
import { View, Text, Image } from "react-native";
import {
  Card,
  CardTitle,
  CardContent,
  CardAction,
  CardButton,
  CardImage
} from "react-native-material-cards";
import NearByFriend from "./NearByFriend";

export default class NearByFriendsCard extends Component {
  styles = {
    card: {
      maxWidth: 350,
      alignItems: "center",
      borderWidth: 0.5,
      borderRadius: 5
    }
  };
  myArray = [
    {
      id: 824233,
      Name: "Salman Khan",
      country: "India",
      city: "mumbai",
      longitude: "55.7878787",
      latitude: "111.897779",
      distance_from_me: 1123
    },
    {
      id: 824234,
      Name: "Sharuk Khan",
      country: "India",
      city: "mumbai",
      longitude: "56.7878787",
      latitude: "112.897779",
      distance_from_me: 1129
    },
    {
      id: 824235,
      Name: "Amir Khan",
      country: "India",
      city: "mumbai",
      longitude: "58.7878787",
      latitude: "113.897779",
      distance_from_me: 1130
    }
  ];

  render() {
    return (
      <View>
        <Card style={this.styles.card}>
          <CardTitle
            title="Near By Friends"
            subtitle="Friends in List are closer than they appear"
          />
          <CardContent>
            {this.myArray.map((obj, indx) => {
              return (
                <NearByFriend name={obj.Name} dist={obj.distance_from_me} />
              );
            })}
          </CardContent>
          <CardAction separator={true} inColumn={false}>
            <CardButton
              onPress={() => {}}
              title="View All Friends"
              color="blue"
            />
          </CardAction>
        </Card>
      </View>
    );
  }
}

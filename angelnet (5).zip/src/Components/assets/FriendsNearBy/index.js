import React, { Component } from "react";
import NearByFriends from "./NearByFriends";
export default class FriendsNearBy extends Component {
  render() {
    return <NearByFriends />;
  }
}

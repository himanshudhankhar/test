import React, { Component } from "react";
import { View, Text, Image } from "react-native";
import {
  Card,
  CardTitle,
  CardContent,
  CardAction,
  CardButton,
  CardImage
} from "react-native-material-cards";
export default class NearByFriend extends Component {
  render() {
    return (
      <Card
        style={{
          flex: 1,
          flexDirection: "row",
          maxWidth: 500,
          maxHeight: 80
        }}
      >
        <Image
          style={{
            width: 30,
            height: 30,
            borderRadius: 15,
            marginRight: 2,
            marginLeft: 9,
            marginTop: 18
          }}
          resizeMode="contain"
          source={{
            uri: "https://s3.amazonaws.com/uifaces/faces/twitter/brynn/128.jpg"
          }}
        />

        <CardTitle
          title={this.props.name}
          subtitle={this.props.dist + " km"}
          style={{
            fontSize: 10
          }}
        />

        <CardAction separator={true} inColumn={false}>
          <CardButton onPress={() => {}} title="ADD" color="blue" />
        </CardAction>
      </Card>
    );
  }
}

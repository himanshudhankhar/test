import React, { Component } from "react";
import Grid from "@material-ui/core/Grid";
import ProfileCard from "../ProfileCard";
import PostNewJobCard from "../PostNewJobCard";
import JobsToSee from "../JobsToSee";
import FriendsNearByCard from "../FriendsNearBy";
import ScrollView from "react-native";
import PostToSee from "../PostToSee";
export default class BodyHome extends Component {
  render() {
    return (
      <div>
        <Grid container spacing={24} style={{ flex: 1 }}>
          <Grid item xs style={{ flex: 1 }}>
            <ProfileCard />
          </Grid>
          <Grid item xs style={{ flex: 2 }}>
            {/* <ScrollView>
              <PostNewJobCard />
               <JobsToSee />
             </ScrollView>*/}
            <PostNewJobCard />
            <PostToSee />
          </Grid>
          <Grid item xs style={{ flex: 1 }}>
            <FriendsNearByCard />
          </Grid>
        </Grid>
      </div>
    );
  }
}

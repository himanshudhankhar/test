import React, { Component } from "react";
import { View, Text, Image } from "react-native";

import Button from "@material-ui/core/Button";
import Paper from "@material-ui/core/Paper";
import {
  Card,
  CardTitle,
  CardContent,
  CardAction,
  CardButton,
  CardImage
} from "react-native-material-cards";

import { Avatar } from "react-native-elements";
import Divider from "react-native-divider";
export default class UserAccountCard extends Component {
  styles = {
    card: {
      padding: 16,
      maxWidth: 300,
      alignItems: "center",
      borderWidth: 0.5,
      borderRadius: 5
    },
    media: {
      image: {
        objectFit: "cover"
      }
    },
    ImageStyle: {
      marginRight: 40,
      marginLeft: 40,
      marginTop: 10,
      paddingTop: 20,
      paddingBottom: 20,
      backgroundColor: "#68a0cf",
      borderRadius: 50,
      borderWidth: 1,
      borderColor: "#aaa"
    },
    avatarstyle: {
      marginRight: 40,
      marginLeft: 40,
      marginTop: 10,
      paddingTop: 20,
      paddingBottom: 20,
      backgroundColor: "#68a0cf"
    }
  };

  render() {
    return (
      <View>
        {/*<Card style={this.styles.card}>
        <CardActionArea>
          <CardMedia
            component="img"
            alt="Contemplative Reptile"
            style={this.styles.media.image}
            height="140"
            src='https://www.google.com/imgres?imgurl=https%3A%2F%2Fcdn.images.express.co.uk%2Fimg%2Fdynamic%2F109%2F590x%2Flizz-1003046.jpg%3Fr%3D1534219722519&imgrefurl=https%3A%2F%2Fwww.express.co.uk%2Flife-style%2Ftop10facts%2F1003046%2F10-facts-world-lizard-day-london-zoo&docid=RI874SmO74i4aM&tbnid=u-K1--cz7I4EpM%3A&vet=10ahUKEwiPx_bTgP3fAhWLLI8KHbRtCOMQMwhqKAMwAw..i&w=590&h=350&bih=626&biw=1366&q=lizard&ved=0ahUKEwiPx_bTgP3fAhWLLI8KHbRtCOMQMwhqKAMwAw&iact=mrc&uact=8'
            title="Contemplative Reptile"
            backgroundColor='#d00'


          />
          <CardContent  >
            <Typography gutterBottom variant="h5" component="h2" style={{display:'flex',alignItems:'center'}} >
             Himanshu Dhankhar 
          </Typography>
            <Typography component="p">
              Co-owner
          </Typography>
          </CardContent>
        </CardActionArea>
        <CardActions>
          <Button size="small" color="primary">
            Share
        </Button>
          <Button size="small" color="primary">
            Learn More
        </Button>
        </CardActions>
      </Card>*/}

        <Card style={this.styles.card}>
          <Image
            style={{
              width: 80,
              height: 80,
              borderRadius: 40,
              marginRight: 40,
              marginLeft: 40,
              marginTop: 10,
              paddingTop: 20,
              paddingBottom: 20
            }}
            resizeMode="contain"
            source={{
              uri:
                "https://facebook.github.io/react-native/docs/assets/favicon.png"
            }}
          />
          {/*<CardImage 
            style={this.styles.ImageStyle}
          source={{ uri: "http://placehold.it/480x270" }}
            resizeMode='contain'
           />*/}

          <CardTitle title="Himanshu Dhankhar" />

          <CardContent text="Enthusiast | Learner | Coder " />
          <Divider borderColor="#ddd" color="#ddd">
            Rank
          </Divider>
          <CardContent>
            <View
              style={{
                flex: 1,
                flexDirection: "row"
              }}
            >
              <h4 style={{ padding: 5 }}>Global Rank: {0}</h4>
              <h4 style={{ padding: 5 }}>Global Reach:{0}</h4>
            </View>
          </CardContent>
          <Divider borderColor="#ddd" color="#ddd">
            Connections
          </Divider>
          <CardContent>
            <View
              style={{
                flex: 1,
                flexDirection: "row"
              }}
            >
              <h4 style={{ padding: 5 }}>Connections: {0}</h4>
              <h4 style={{ padding: 5 }}>Followers:{0}</h4>
            </View>
          </CardContent>

          <CardAction seperator={true} inColumn={false}>
            <CardButton onPress={() => {}} title="Edit" color="blue" />
          </CardAction>
        </Card>
      </View>
    );
  }
}

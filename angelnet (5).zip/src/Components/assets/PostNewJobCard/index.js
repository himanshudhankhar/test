import React, { Component } from "react";
import {
  Card,
  CardTitle,
  CardContent,
  CardAction,
  CardButton,
  CardImage
} from "react-native-material-cards";
import { View, TextInput, Text } from "react-native";
import Fab from "@material-ui/core/Fab";
import Button from "@material-ui/core/Button";
import Image from "@material-ui/icons/PermMedia";
import Icon from "@material-ui/core/Icon";
export default class PostJobCard extends Component {
  render() {
    return (
      <Card
        style={{
          flex: 1,

          maxWidth: 600,
          borderWidth: 0.5,
          borderRadius: 10
        }}
      >
        <View>
          <TextInput
            style={{ height: 80, minWidth: 600, fontSize: 15, padding: 10 }}
            onChangeText={text => this.setState({ input: text })}
            placeholder="Share your new innovation with friends"
          />
        </View>

        <CardAction separator={true} inColumn={false}>
          <Button
            variant="contained"
            style={{
              backgroundColor: "#fff",
              marginTop: 5,
              marginBottom: 5,
              marginLeft: 15,
              marginRight: 15,
              borderRadius: 40
            }}
          >
            <Image color="primary" />
            <p
              style={{
                fontWeight: "bold",
                color: "blue",
                marginLeft: 5
              }}
            >
              Upload
            </p>
          </Button>

          <CardButton onPress={() => {}} title="Post" color="blue" />
        </CardAction>
      </Card>
    );
  }
}

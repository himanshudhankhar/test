import React, { Component } from "react";
import { ScrollView } from "react-native";
import HomePageHeader from "./Header/HomePageHeader";
import BodyHome from "./Components/assets/Body/BodyHome";
import FooterHome from "./Components/assets/Footer/FooterHome";
export default class App extends Component {
  styles = {
    container: {
      flex: 1
    }
  };
  render() {
    return (
      <ScrollView styles={this.styles.container}>
        <HomePageHeader />
        <BodyHome />
        <FooterHome />
      </ScrollView>
    );
  }
}

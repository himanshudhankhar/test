import React, { Component } from "react";
import { View, Image, Text } from "react-native";
import { SearchBar } from "react-native-elements";
import Header from "./Header";

export default class HomePageHeader extends Component {
  render() {
    return <Header />;
  }
}
